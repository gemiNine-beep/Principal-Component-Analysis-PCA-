# PCA-Based Identification of Essential Variables — Breast Cancer Dataset

This project uses **Principal Component Analysis (PCA)** to identify the most
important variables driving variance in the Breast Cancer Wisconsin
(Diagnostic) dataset, and reduces the dataset from 30 features down to 2
principal components for visualization and further analysis.

## Contents

- `PCA.ipynb` — Jupyter/Colab notebook containing the full analysis
- `outputs/` — Folder created by the notebook containing generated charts and CSV files (see [Outputs](#outputs) below)

## Dataset

The notebook uses the **Breast Cancer Wisconsin (Diagnostic)** dataset,
loaded directly from `sklearn.datasets.load_breast_cancer`. No external file
download is required.

- **Samples:** 569
- **Features:** 30 numeric measurements (e.g. radius, texture, perimeter, area, concavity, etc.)
- **Target:** Diagnosis — `0 = malignant`, `1 = benign`

## Requirements

Install the following Python packages before running the notebook:

```bash
pip install numpy pandas matplotlib scikit-learn
```

The notebook was authored for use in Google Colab but runs in any standard
Jupyter environment.

## How to Run

1. Open `PCA.ipynb` in Jupyter Notebook, JupyterLab, VS Code, or Google Colab.
2. Run all cells from top to bottom (**Runtime → Run all** in Colab, or
   **Kernel → Restart & Run All** in Jupyter).
3. Before running, make sure a folder named `outputs` exists in the same
   directory as the notebook (or let the first code cell create it), since
   several cells save figures and CSV files to `outputs/`.
4. Charts will display inline as each cell runs, and results will also be
   saved to disk.

## What the Notebook Does

The notebook proceeds through the following steps:

1. **Load libraries and data**
   Imports NumPy, pandas, matplotlib, and the relevant scikit-learn modules
   (`StandardScaler`, `PCA`, `train_test_split`, `LogisticRegression`, and
   assorted classification metrics). Loads the Breast Cancer dataset into a
   pandas DataFrame (`X`) and target Series (`y`).

2. **Standardize the features**
   Since PCA is sensitive to feature scale, all 30 features are standardized
   (zero mean, unit variance) using `StandardScaler`.

3. **Fit a full PCA model**
   A `PCA()` model is fit on all standardized features to compute the
   explained variance ratio for every component, along with the cumulative
   explained variance.

4. **Determine components needed for 90% / 95% variance**
   The notebook calculates how many principal components are required to
   capture 90% and 95% of the total variance in the dataset (found to be **7**
   and **10** components, respectively, for this dataset).

5. **Visualize variance explained**
   A two-panel figure is generated:
   - A **scree plot** of the top 10 components' individual variance explained
   - A **cumulative explained variance** curve with reference lines at 90%
     and 95%

   Saved as `outputs/1_scree_cumulative_variance.png`.

6. **Identify the most essential variables**
   The loadings (coefficients) of the first two principal components (PC1
   and PC2) are extracted for every original feature. The notebook reports
   the **top 10 features** contributing most strongly (by absolute loading)
   to PC1 and to PC2, and saves the full loading matrix to
   `outputs/pca_loadings_all_features.csv`.

   For this dataset, the variables driving **PC1** most strongly are related
   to tumor size and shape irregularity (e.g. *mean concave points*, *mean
   concavity*, *worst concave points*, *mean compactness*, *worst perimeter*).

7. **Visualize top contributing variables**
   A horizontal bar chart of the top 10 variables driving PC1 is generated
   and saved as `outputs/2_top_variables_pc1.png`.

8. **Reduce to 2 principal components**
   The dataset is reduced to just 2 principal components using
   `PCA(n_components=2)`. The notebook reports the variance explained by
   each of the two components individually and combined (PC1 ≈ 44.3%,
   PC2 ≈ 19.0%, total ≈ 63.2%).

   The reduced 2D dataset (with diagnosis labels) is saved to
   `outputs/breast_cancer_2_components.csv`.

9. **Visualize the 2D projection**
   A scatter plot of the data projected onto PC1 and PC2, colored by
   diagnosis (malignant vs. benign), is generated and saved as
   `outputs/3_pca_2d_projection.png`. This plot shows that even with just 2
   components, malignant and benign samples form largely separable clusters.

## Outputs

Running the notebook end-to-end produces the following files inside an
`outputs/` folder:

| File | Description |
|---|---|
| `1_scree_cumulative_variance.png` | Scree plot + cumulative explained variance chart |
| `2_top_variables_pc1.png` | Bar chart of top 10 variables driving PC1 |
| `3_pca_2d_projection.png` | 2D scatter plot of data projected onto PC1/PC2, colored by diagnosis |
| `pca_loadings_all_features.csv` | Loadings of every original feature on PC1 and PC2 |
| `breast_cancer_2_components.csv` | Dataset reduced to 2 principal components, with diagnosis labels |

## Key Findings

- **7 components** are needed to explain 90% of the variance in the data;
  **10 components** are needed for 95%.
- The two principal components alone explain about **63%** of total
  variance.
- The features most responsible for variance along PC1 relate to tumor
  **size and boundary irregularity** (concavity, concave points,
  compactness, perimeter, area).
- The features most responsible for variance along PC2 relate more to
  **fractal dimension** and radius/area (with mixed signs, indicating an
  axis somewhat orthogonal to overall tumor size).
- Projecting the data onto just 2 principal components still gives visible
  separation between malignant and benign samples, suggesting PCA is an
  effective dimensionality-reduction technique for this dataset.

## Notes

- Random elements (e.g. any train/test splitting code present but not
  necessarily used in the current version) are not seeded beyond what
  scikit-learn defaults provide; re-running the notebook should reproduce
  the same PCA results since PCA itself is deterministic given the same
  input data.
- If you re-run the notebook and the `outputs/` folder does not exist yet,
  create it first (`mkdir outputs`) or add a cell with
  `os.makedirs("outputs", exist_ok=True)` before the first `plt.savefig`
  call.
